export default function MagazinePage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Magazine</h1>
      <p>Articles and stories coming soon...</p>
    </main>
  );
}
