export default function ShopPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Shop</h1>
      <p>Products and collections coming soon...</p>
    </main>
  );
}
