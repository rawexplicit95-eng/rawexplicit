export default function HomePage() {
  return (
    <main style={{ textAlign: 'center', padding: '4rem' }}>
      <h1>RAW Explicit Brand</h1>
      <p>Magazine • Shop • Culture</p>
    </main>
  );
}
